-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 18-12-2014 a las 12:15:35
-- Versión del servidor: 5.5.38
-- Versión de PHP: 5.6.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de datos: `35mmDB`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `albumes`
--

CREATE TABLE `albumes` (
`IdAlbum` int(11) NOT NULL,
  `Titulo` text COLLATE utf8_spanish_ci NOT NULL,
  `Descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Pais` int(11) NOT NULL,
  `Usuario` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `albumes`
--

INSERT INTO `albumes` (`IdAlbum`, `Titulo`, `Descripcion`, `Fecha`, `Pais`, `Usuario`) VALUES
(1, 'Album1', 'Album de prueba', '2014-10-01', 1, 1),
(4, 'Tochulomialbum', 'Album to chulo', '2014-11-03', 2, 1),
(5, 'Album guai', 'Guai album', '2014-11-18', 3, 2),
(10, 'asdf', 'asdf', '1993-10-19', 4, 45),
(11, '123', '', '0000-00-00', 5, 45),
(13, '', 'sd', '1993-10-19', 1, 45),
(14, 'uu', '', '0000-00-00', 1, 45),
(15, '12354', 'Pues aquÃ­ estaremos sabe u no', '1993-10-19', 1, 45);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fotos`
--

CREATE TABLE `fotos` (
`IdFoto` int(11) NOT NULL,
  `Titulo` text COLLATE utf8_spanish_ci NOT NULL,
  `Descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `Fecha` date DEFAULT NULL,
  `Pais` int(11) NOT NULL,
  `Album` int(11) DEFAULT NULL,
  `Fichero` text COLLATE utf8_spanish_ci NOT NULL,
  `FRegistro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Usuario` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `fotos`
--

INSERT INTO `fotos` (`IdFoto`, `Titulo`, `Descripcion`, `Fecha`, `Pais`, `Album`, `Fichero`, `FRegistro`, `Usuario`) VALUES
(57, 'aa', '', '0000-00-00', 1, NULL, 'photos/46/Escanear*AA***AAAeeeeeeennnnnnnnnj==1.jpeg', '2014-12-10 09:14:10', 46),
(58, 'aa', '', '0000-00-00', 1, NULL, 'photos/46/EscanearAAAAAeeeeeeennnnnnnnnj==1.jpeg', '2014-12-10 09:14:40', 46),
(59, 'aa', '', '0000-00-00', 1, NULL, 'photos/46/EscanearAAAAAeeeeeeennnnnnnnnj==1.jpeg', '2014-12-10 09:15:05', 46),
(60, 'aa', '', '0000-00-00', 1, NULL, 'photos/46/60EscanearAAAAAeeeeeeennnnnnnnnj==1.jpeg', '2014-12-10 09:15:34', 46),
(61, '1', '', '0000-00-00', 1, NULL, 'photos/46/61DSC_0065.jpg', '2014-12-10 09:19:58', 46),
(63, 'aa', '', '0000-00-00', 1, NULL, 'photos/46/63IMG_20131214_130501.jpg', '2014-12-10 09:28:05', 46),
(65, '21', '', '0000-00-00', 1, NULL, 'photos/46/65IMG_20140729_105548.jpg', '2014-12-10 09:29:12', 46),
(66, '32', '', '0000-00-00', 1, NULL, 'photos/46/66PANO_20140312_112608.jpg', '2014-12-10 09:32:18', 46),
(67, 'LP', '', '0000-00-00', 1, NULL, 'photos/46/67IMG_20140729_110421.jpg', '2014-12-10 11:07:08', 46),
(72, '213', '', '0000-00-00', 1, NULL, 'photos/46/68sportchannelsoccer160012561.jpg', '2014-12-10 11:20:14', 46),
(73, '111', '', '0000-00-00', 1, NULL, 'photos/46/73luketwymanwallpaper2560x1440.jpg', '2014-12-10 11:20:42', 46),
(74, 'pano', '', '0000-00-00', 1, NULL, 'photos/46/74PANO_20140312_112608.jpg', '2014-12-10 11:21:24', 46),
(75, 'Clash', 'The clash', '1993-10-19', 1, NULL, 'photos/45/75IMG_20131204_140818.jpg', '2014-12-10 16:35:05', 45),
(76, 'Keyboard', '', '0000-00-00', 1, NULL, 'photos/45/76IMG_20140202_003921.jpg', '2014-12-10 16:36:23', 45),
(77, 'Camino', '', '0000-00-00', 1, NULL, 'photos/45/772014090510.48.161.jpg', '2014-12-10 16:39:27', 45),
(78, 'Low poly', '', '0000-00-00', 1, NULL, 'photos/45/78the_red_mountains_by_toilettenmassakerd6dux3c.jpg', '2014-12-10 16:45:24', 45),
(79, 'Camino', '', '0000-00-00', 1, NULL, 'photos/45/79IMG_20140904_181701.jpg', '2014-12-10 16:46:57', 45),
(80, 'Cruz de hierro', '', '0000-00-00', 1, NULL, 'photos/45/80IMG_20140905_084457.jpg', '2014-12-10 16:47:29', 45),
(82, 'asdf', '', '0000-00-00', 6, NULL, 'photos/45/81DSC_0015.jpg', '2014-12-10 17:19:41', 45),
(83, '324', '', '0000-00-00', 6, NULL, 'photos/45/83DSC_0013.jpg', '2014-12-10 17:20:25', 45),
(84, '324', '', '0000-00-00', 6, NULL, 'photos/45/84DSC_0013.jpg', '2014-12-10 17:20:26', 45),
(85, '11', '', '0000-00-00', 6, NULL, 'photos/45/85DSC_0009.jpg', '2014-12-10 17:21:00', 45),
(86, '11', '', '0000-00-00', 6, NULL, 'photos/45/85DSC_0009.jpg', '2014-12-10 17:21:00', 45),
(87, '11', '', '0000-00-00', 6, NULL, 'photos/45/85DSC_0009.jpg', '2014-12-10 17:21:00', 45),
(88, '11', '', '0000-00-00', 6, NULL, 'photos/45/884g5TMj6Kk_big.png', '2014-12-10 18:21:36', 45),
(89, 'jpeg', '', '0000-00-00', 6, NULL, 'photos/45/89Escanear.jpeg', '2014-12-10 18:22:21', 45),
(90, 'Yum', '', '0000-00-00', 6, NULL, 'photos/47/90IMG_20140613_201556.jpg', '2014-12-11 08:51:44', 47),
(91, 'LP', '', '0000-00-00', 6, NULL, 'photos/47/91IMG_20140729_110451.jpg', '2014-12-11 08:52:21', 47),
(92, 'Ec', '', '0000-00-00', 6, NULL, 'photos/47/92DSC_0062.jpg', '2014-12-11 08:53:16', 47),
(93, 'Movris', '', '0000-00-00', 6, NULL, 'photos/47/931.jpg', '2014-12-11 08:59:06', 47),
(94, 'POSOK', '', '0000-00-00', 6, NULL, 'photos/45/94TtLHZOG.jpg', '2014-12-11 10:13:18', 45),
(95, 'Esta si que mola', '', '0000-00-00', 6, NULL, 'photos/45/95wp_2880.jpg', '2014-12-11 10:19:19', 45),
(96, 'Loco', '', '0000-00-00', 6, NULL, 'photos/45/96IMG_20140905_092756.jpg', '2014-12-11 10:25:39', 45),
(97, '12', '', '2014-12-11', 6, NULL, 'photos/45/97IMG_20140901_095219.jpg', '2014-12-11 10:29:49', 45),
(98, 'High', '', '2014-12-11', 6, NULL, 'photos/45/982014083107.49.361.jpg', '2014-12-11 10:32:57', 45),
(99, 'High', '', '1993-10-19', 6, NULL, 'photos/45/992014083107.49.361.jpg', '2014-12-11 10:33:06', 45),
(100, 'Ohooho', '', '2014-12-11', 6, NULL, 'photos/45/100IMG_20140830_111720.jpg', '2014-12-11 12:07:46', 45),
(101, 'Aaaa', '', '2014-12-12', 6, NULL, 'photos/53/101Capturadepantalla20141211alas19.46.14.png', '2014-12-12 13:15:19', 53);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE `paises` (
`IdPais` int(11) NOT NULL,
  `NomPais` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`IdPais`, `NomPais`) VALUES
(1, 'England'),
(2, 'Spain'),
(3, 'Zimbaue'),
(4, 'Holanda'),
(5, 'Marruecos'),
(6, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
`IdUsuarios` int(11) NOT NULL,
  `NomUsuario` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `password` text COLLATE utf8_spanish_ci NOT NULL,
  `email` text COLLATE utf8_spanish_ci NOT NULL,
  `sexo` tinyint(4) NOT NULL,
  `FNacimiento` date NOT NULL,
  `Ciudad` text COLLATE utf8_spanish_ci NOT NULL,
  `Pais` int(11) NOT NULL,
  `Foto` text COLLATE utf8_spanish_ci NOT NULL,
  `FRegistro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`IdUsuarios`, `NomUsuario`, `password`, `email`, `sexo`, `FNacimiento`, `Ciudad`, `Pais`, `Foto`, `FRegistro`) VALUES
(1, 'luthor', '1234', '', 0, '0000-00-00', '', 3, '1', '2014-11-24 17:39:34'),
(2, 'alex', '1234', '', 0, '0000-00-00', '', 3, '1', '2014-11-24 17:39:34'),
(3, 'pepe', '123456', '', 0, '0000-00-00', '', 3, '1', '2014-11-28 13:32:58'),
(7, '444', 'aaa', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 19:43:29'),
(8, 'aadf', 'adf', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 19:44:06'),
(11, 'alex23', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 19:50:07'),
(12, 'alex235', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 19:50:26'),
(29, 'aweqwer', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 20:02:29'),
(31, '1234', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 20:04:04'),
(32, '12345', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 20:09:57'),
(35, '12345666', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 20:18:20'),
(36, '123456665', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 20:18:59'),
(37, '1', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 22:37:51'),
(38, '132', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-04 22:38:02'),
(39, '565468', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-05 08:35:41'),
(40, '5654682', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-05 08:36:39'),
(41, '56546822', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-05 08:39:28'),
(42, '14477', '1234657', '', 0, '0000-00-00', '', 3, '1', '2014-12-05 08:47:17'),
(43, '1447732', '1234567', '', 0, '0000-00-00', '', 3, '1', '2014-12-05 08:48:40'),
(45, 'luth', 'c4ca4238a0b923820dcc509a6f75849b', 'ewr31', 0, '0000-00-00', 'wer', 1, 'photosProfile/45.png', '2014-12-05 12:19:20'),
(46, 'pim', '81dc9bdb52d04dc20036dbd8313ed055', 'pom@pam.com', 0, '0000-00-00', 'Marruecos', 1, 'photosProfile/50DSC_0065.jpg', '2014-12-10 09:02:49'),
(47, 'pom', 'fcea920f7412b5da7be0cf42b8c93759', 'aletormat@gmail.com', 0, '0000-00-00', 'Elche', 2, 'photosProfile/47.png', '2014-12-10 18:37:39'),
(50, 'yum', 'fcea920f7412b5da7be0cf42b8c93759', 'aletormat@gmail.com', 0, '0000-00-00', 'Elche', 6, 'photosProfile/50DSC_0065.jpg', '2014-12-10 18:42:01'),
(51, 'asfew', 'fcea920f7412b5da7be0cf42b8c93759', 'a3406572@trbvm.com', 0, '0000-00-00', 'ww', 6, '1', '2014-12-10 19:01:17'),
(52, 'sss', 'fcea920f7412b5da7be0cf42b8c93759', 'a3406572@trbvm.com', 0, '0000-00-00', 'sdf', 6, '1', '2014-12-10 19:03:02'),
(53, '1234aa', 'fcea920f7412b5da7be0cf42b8c93759', '1234@1234.com', 0, '0000-00-00', 'Elche', 1, 'photosProfile/53.png', '2014-12-12 13:14:06');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `albumes`
--
ALTER TABLE `albumes`
 ADD PRIMARY KEY (`IdAlbum`), ADD KEY `pais` (`Pais`), ADD KEY `usuAlbum` (`Usuario`) COMMENT 'clave ajena usuario album';

--
-- Indices de la tabla `fotos`
--
ALTER TABLE `fotos`
 ADD PRIMARY KEY (`IdFoto`), ADD KEY `albumFotos` (`Album`), ADD KEY `paisFotos` (`Pais`), ADD KEY `usuFotos` (`Usuario`);

--
-- Indices de la tabla `paises`
--
ALTER TABLE `paises`
 ADD PRIMARY KEY (`IdPais`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`IdUsuarios`), ADD UNIQUE KEY `NomUsuario` (`NomUsuario`), ADD KEY `paisUsu` (`Pais`) COMMENT 'lista paises relacionada con usuarios';

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `albumes`
--
ALTER TABLE `albumes`
MODIFY `IdAlbum` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT de la tabla `fotos`
--
ALTER TABLE `fotos`
MODIFY `IdFoto` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT de la tabla `paises`
--
ALTER TABLE `paises`
MODIFY `IdPais` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
MODIFY `IdUsuarios` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `albumes`
--
ALTER TABLE `albumes`
ADD CONSTRAINT `albumPais` FOREIGN KEY (`Pais`) REFERENCES `paises` (`IdPais`),
ADD CONSTRAINT `albumUsu` FOREIGN KEY (`Usuario`) REFERENCES `usuarios` (`IdUsuarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fotos`
--
ALTER TABLE `fotos`
ADD CONSTRAINT `albumFotos` FOREIGN KEY (`Album`) REFERENCES `albumes` (`IdAlbum`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `paisFotos` FOREIGN KEY (`Pais`) REFERENCES `paises` (`IdPais`),
ADD CONSTRAINT `usuarioFoto` FOREIGN KEY (`Usuario`) REFERENCES `usuarios` (`IdUsuarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`Pais`) REFERENCES `paises` (`IdPais`) ON DELETE CASCADE ON UPDATE CASCADE;
